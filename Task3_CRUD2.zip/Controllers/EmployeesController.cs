﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Azure.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Task3_CRUDOperations.Data;
using Task3_CRUDOperations.Models;

namespace Task3_CRUDOperations.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _usermanager;
        private readonly RoleManager<IdentityRole> _rolemanager;

        public EmployeesController(ApplicationDbContext context, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> rolemanager)
        {
            _context = context;
            _usermanager = userManager;
            _rolemanager = rolemanager;
        }

        // GET: Employees
        public async Task<IActionResult> Index()
        {
            return View(await _context.Employees.ToListAsync());
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Employees/Create
        [Authorize(Roles ="Admin")]
        public IActionResult Create()
        {
            var roles = _rolemanager.Roles
            .Select(r => new SelectListItem { Value = r.Name, Text = r.Name })
            .ToList();

            ViewBag.Roles = roles;
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([Bind("Id,Name,Email,password,Phone,Salary,Role")] Employee employee)
        {
            var existingUser = await _usermanager.FindByEmailAsync(employee.Email);
            if (existingUser != null)
            {
                ModelState.AddModelError("Email", "This email is already used. Please choose another one.");
                return View(employee);
            }
            if (ModelState.IsValid)
            {
                var user = new IdentityUser
                {
                    Email = employee.Email,
                    UserName = employee.Email                  
                };
                var result = await _usermanager.CreateAsync(user, employee.password);
                if (result.Succeeded)
                {
                await _usermanager.AddToRoleAsync(user, employee.Role);
                employee.UserId = user.Id;

                _context.Add(employee);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
                }
            }
            var roles = _rolemanager.Roles
            .Select(r => new SelectListItem { Value = r.Name, Text = r.Name })
            .ToList();
            ViewBag.Roles = roles;
            return View(employee);
        }

        // GET: Employees/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            var roles = _rolemanager.Roles
            .Select(r => new SelectListItem { Value = r.Name, Text = r.Name })
            .ToList();
            ViewBag.Roles = roles;
            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Email,Phone,Salary,Role,UserId")] Employee employee)
        {
            var roles = _rolemanager.Roles
            .Select(r => new SelectListItem { Value = r.Name, Text = r.Name })
            .ToList();
            ViewBag.Roles = roles;
            var user = await _usermanager.FindByIdAsync(employee.UserId);
            if (id != employee.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var previous_role = await _usermanager.GetRolesAsync(user);
                    await _usermanager.RemoveFromRolesAsync(user, previous_role);
                    await _usermanager.AddToRoleAsync(user, employee.Role);
                    user.Email = employee.Email;
                    user.NormalizedEmail = employee.Email.ToUpper();
                    user.UserName = employee.Email; 
                    user.NormalizedUserName = employee.Email.ToUpper(); 
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employee);
        }

        // GET: Employees/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employees
                .FirstOrDefaultAsync(m => m.Id == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                var user = await _usermanager.FindByIdAsync(employee.UserId);
                _context.Employees.Remove(employee);
                await _usermanager.DeleteAsync(user);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employees.Any(e => e.Id == id);
        }
    }
}
