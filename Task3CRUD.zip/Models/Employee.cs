﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Task3_CRUDOperations.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        [NotMapped]
        public string? password { get; set; }
        public string? Phone { get; set; }
        public double? Salary { get; set; }
        public string? Role { get; set; }
        public string? UserId { get; set; }
    }
}
